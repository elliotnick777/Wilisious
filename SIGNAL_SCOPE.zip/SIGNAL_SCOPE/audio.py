"""Bounded-memory PCM WAV analysis. No decoding tools or network access."""
from dataclasses import dataclass
from pathlib import Path
import math
import os
import tempfile
import wave

import numpy as np

CHUNK = 65536


@dataclass(frozen=True)
class Source:
    path: Path
    rate: int
    channels: int
    width: int
    frames: int

    @property
    def duration(self):
        return self.frames / self.rate

    def open(self):
        reader = wave.open(str(self.path), 'rb')
        signature = (reader.getframerate(), reader.getnchannels(), reader.getsampwidth(), reader.getnframes())
        if signature != (self.rate, self.channels, self.width, self.frames):
            reader.close()
            raise ValueError('The source file has changed. Open it again.')
        return reader


def open_source(path):
    path = Path(path).resolve(strict=True)
    if path.suffix.lower() != '.wav':
        raise ValueError('Choose an uncompressed PCM .wav file.')
    try:
        with wave.open(str(path), 'rb') as reader:
            rate, channels, width, frames = (reader.getframerate(), reader.getnchannels(),
                                             reader.getsampwidth(), reader.getnframes())
            if reader.getcomptype() != 'NONE' or width not in (1, 2, 3, 4):
                raise ValueError('Supported WAV: uncompressed 8, 16, 24 or 32-bit integer PCM.')
            if not 1 <= channels <= 32 or not 1 <= rate <= 768000 or frames < 1:
                raise ValueError('The WAV has invalid parameters or contains no audio.')
            # Seek through chunks, verifying declared data without holding it in RAM.
            remaining = frames
            while remaining:
                count = min(CHUNK, remaining)
                data = reader.readframes(count)
                if len(data) != count * width * channels:
                    raise ValueError('The WAV data is truncated.')
                remaining -= count
    except wave.Error as exc:
        raise ValueError('Cannot read this WAV. Use integer PCM, not float or compressed WAV.') from exc
    return Source(path, rate, channels, width, frames)


def decode(raw, width, channels):
    if len(raw) % (width * channels):
        raise ValueError('Incomplete PCM frame.')
    if width == 1:
        values = (np.frombuffer(raw, np.uint8).astype(np.float32) - 128) / 128
    elif width == 2:
        values = np.frombuffer(raw, '<i2').astype(np.float32) / 32768
    elif width == 3:
        b = np.frombuffer(raw, np.uint8).reshape(-1, 3).astype(np.int32)
        v = b[:, 0] | (b[:, 1] << 8) | (b[:, 2] << 16)
        v = (v ^ 0x800000) - 0x800000
        values = v.astype(np.float32) / 8388608
    elif width == 4:
        values = (np.frombuffer(raw, '<i4').astype(np.float64) / 2147483648).astype(np.float32)
    else:
        raise ValueError('Unsupported PCM sample width.')
    return values.reshape(-1, channels)


def frame_range(source, start, end):
    if not math.isfinite(start) or not math.isfinite(end):
        raise ValueError('Selection times must be finite.')
    first = max(0, min(source.frames, round(start * source.rate)))
    last = max(0, min(source.frames, round(end * source.rate)))
    if last <= first:
        raise ValueError('Select at least one audio frame.')
    return first, last


def channel_samples(samples, channel):
    if channel == -1:
        return samples.mean(axis=1)
    if not 0 <= channel < samples.shape[1]:
        raise ValueError('Invalid channel.')
    return samples[:, channel]


def dbfs(value):
    return 20 * math.log10(max(float(value), 1e-12))


def analyze(source, start, end, channel=0, nfft=2048, columns=1200):
    """Exact waveform/metrics; bounded, time-sampled STFT for long views.

    Spectrum: Hann-windowed peak amplitude in dBFS (not power/Hz).
    Silence: all-channel RMS <= -50 dBFS in 20 ms blocks, runs >= 0.25 s.
    """
    if nfft not in (512, 1024, 2048, 4096):
        raise ValueError('Invalid FFT size.')
    if not 1 <= columns <= 2400:
        raise ValueError('Invalid overview size.')
    first, last = frame_range(source, start, end)
    count = last - first
    bins = min(columns, count)
    lo = np.full(bins, np.inf, dtype=np.float32)
    hi = np.full(bins, -np.inf, dtype=np.float32)
    peak, square_sum, clipped = 0., 0., 0
    silence = []
    block = max(1, round(source.rate * .02))
    carry = np.empty((0, source.channels), dtype=np.float32)
    block_position = first
    silent_start = None

    def silence_block(samples, position):
        nonlocal silent_start
        quiet = float(np.mean(samples.astype(np.float64) ** 2)) <= 10 ** (-50 / 10)
        if quiet and silent_start is None:
            silent_start = position
        if not quiet and silent_start is not None:
            if position - silent_start >= source.rate * .25:
                silence.append((silent_start / source.rate, position / source.rate))
            silent_start = None

    with source.open() as reader:
        reader.setpos(first)
        position = first
        while position < last:
            take = min(CHUNK, last - position)
            raw = reader.readframes(take)
            if len(raw) != take * source.width * source.channels:
                raise ValueError('Audio data changed or became unreadable.')
            samples = decode(raw, source.width, source.channels)
            mono = channel_samples(samples, channel)
            indexes = ((np.arange(take, dtype=np.int64) + position - first) * bins) // count
            np.minimum.at(lo, indexes, mono)
            np.maximum.at(hi, indexes, mono)
            peak = max(peak, float(np.max(np.abs(mono))))
            square_sum += float(np.dot(mono.astype(np.float64), mono.astype(np.float64)))
            # Count actual full-scale integer samples, across all source channels.
            if source.width == 1:
                ints = np.frombuffer(raw, np.uint8)
                clipped += int(np.count_nonzero((ints == 0) | (ints == 255)))
            elif source.width == 4:
                ints = np.frombuffer(raw, '<i4')
                clipped += int(np.count_nonzero((ints == -2147483648) | (ints == 2147483647)))
            else:
                threshold = 1 - 1 / 2 ** (source.width * 8 - 1)
                clipped += int(np.count_nonzero((samples <= -1) | (samples >= threshold)))
            carry = np.concatenate((carry, samples))
            used = 0
            while len(carry) - used >= block:
                silence_block(carry[used:used + block], block_position)
                used += block
                block_position += block
            carry = carry[used:].copy()
            position += take
        if len(carry):
            silence_block(carry, block_position)
        if silent_start is not None and last - silent_start >= source.rate * .25:
            silence.append((silent_start / source.rate, last / source.rate))

        # At most `columns` windows; never build a file-sized STFT matrix.
        window_count = min(columns, max(1, math.ceil(count / max(1, nfft // 4))))
        centers = np.linspace(first, last - 1, window_count).astype(np.int64)
        spectrum = np.empty((nfft // 2 + 1, window_count), np.float32)
        window = np.hanning(nfft).astype(np.float32)
        for i, center in enumerate(centers):
            left = int(center) - nfft // 2
            read_first, read_last = max(first, left), min(last, left + nfft)
            reader.setpos(read_first)
            samples = decode(reader.readframes(read_last - read_first), source.width, source.channels)
            if len(samples) != read_last - read_first:
                raise ValueError('Audio data changed during spectrum analysis.')
            padded = np.zeros(nfft, np.float32)
            offset = read_first - left
            padded[offset:offset + len(samples)] = channel_samples(samples, channel)
            amplitude = np.abs(np.fft.rfft(padded * window)) * (2 / window.sum())
            amplitude[0] /= 2
            amplitude[-1] /= 2
            spectrum[:, i] = 20 * np.log10(np.maximum(amplitude, 1e-6))
    return {'low': lo, 'high': hi, 'spectrum': spectrum,
            'start': first / source.rate, 'end': last / source.rate,
            'peak': dbfs(peak), 'rms': dbfs(math.sqrt(square_sum / count)),
            'clipped': clipped, 'silence': silence,
            'sampled': count > window_count * (nfft // 4), 'nfft': nfft}


def export_selection(source, destination, start, end):
    target = Path(destination)
    if target.suffix.lower() != '.wav':
        raise ValueError('The output filename must end in .wav.')
    if target.resolve() == source.path.resolve() or (
        target.exists() and os.path.samefile(target, source.path)
    ):
        raise ValueError('The original is protected. Choose another filename.')
    first, last = frame_range(source, start, end)
    fd, temporary = tempfile.mkstemp(prefix='.signal-scope-', dir=target.parent)
    os.close(fd)
    try:
        with source.open() as reader, wave.open(temporary, 'wb') as writer:
            writer.setnchannels(source.channels)
            writer.setsampwidth(source.width)
            writer.setframerate(source.rate)
            reader.setpos(first)
            remaining = last - first
            while remaining:
                take = min(CHUNK, remaining)
                data = reader.readframes(take)
                if len(data) != take * source.channels * source.width:
                    raise ValueError('Source data is truncated.')
                writer.writeframesraw(data)
                remaining -= take
        os.replace(temporary, target)
    finally:
        Path(temporary).unlink(missing_ok=True)
