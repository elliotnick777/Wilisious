"""SIGNAL SCOPE: local WAV inspection with Qt-painted plots."""
import sys
from pathlib import Path

import numpy as np
from PySide6.QtCore import Qt, QThread, Signal, QTimer, QUrl, QRectF, QPointF
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen
from PySide6.QtWidgets import (
    QApplication, QComboBox, QDoubleSpinBox, QFileDialog, QFrame, QHBoxLayout,
    QLabel, QListWidget, QMainWindow, QMessageBox, QPushButton, QScrollBar,
    QSplitter, QVBoxLayout, QWidget,
)
from audio import analyze, export_selection, open_source

STYLE = '''
QWidget { background: #101719; color: #c3ccc7; font-family: "Consolas", "DejaVu Sans Mono", monospace; font-size: 12px; }
QLabel { background: transparent; }
QLabel#title { color: #e5ece3; font-size: 27px; font-weight: bold; }
QLabel#muted { color: #849894; }
QLabel#accent { color: #91c9ac; }
QFrame#panel { border: 1px solid #354541; background: #172022; }
QPushButton, QComboBox, QDoubleSpinBox { background: #1d2b2b; border: 1px solid #455a52; padding: 8px; }
QPushButton:hover { background: #2b4139; border-color: #95b59e; }
QPushButton:disabled { color: #536560; border-color: #2e3e39; }
QPushButton#primary { background: #365e4d; color: #e2f0df; }
QListWidget { background: #10191a; border: 1px solid #354541; padding: 5px; }
QListWidget::item { padding: 7px 3px; }
QListWidget::item:selected { background: #365e4d; }
QScrollBar:horizontal { height: 14px; background: #182526; }
QScrollBar::handle:horizontal { background: #587a69; min-width: 30px; }
QSplitter::handle { background: #101719; }
'''


def text(value, role=None):
    item = QLabel(value)
    if role:
        item.setObjectName(role)
    return item


def button(value, callback):
    item = QPushButton(value)
    item.clicked.connect(callback)
    item.setCursor(Qt.CursorShape.PointingHandCursor)
    return item


class Task(QThread):
    result = Signal(object)
    error = Signal(str)

    def __init__(self, operation, parent):
        super().__init__(parent)
        self.operation = operation

    def run(self):
        try:
            self.result.emit(self.operation())
        except Exception as exc:
            self.error.emit(f'{type(exc).__name__}: {exc}')


class Plot(QWidget):
    selection_changed = Signal(float, float)
    hovered = Signal(str)

    def __init__(self, spectral=False):
        super().__init__()
        self.spectral = spectral
        self.data = None
        self.source = None
        self.image = None
        self.selection = (0., 0.)
        self.anchor = None
        self.floor = -80
        self.playhead = None
        self.setMinimumSize(400, 200)
        self.setMouseTracking(True)

    def area(self):
        return QRectF(62, 32, max(1, self.width() - 83), max(1, self.height() - 66))

    def set_data(self, source, data):
        self.source, self.data = source, data
        if self.spectral:
            self.colorize()
        self.update()

    def colorize(self):
        if self.data is None:
            return
        values = np.clip((self.data['spectrum'] - self.floor) / -self.floor, 0, 1)
        # Fixed scale: darkness is the chosen floor; pale yellow approaches 0 dBFS.
        stops = np.array([[8, 20, 27], [23, 65, 78], [45, 125, 130],
                          [133, 184, 135], [244, 223, 149]], dtype=float)
        positions = np.linspace(0, 1, len(stops))
        rgb = np.stack([np.interp(values, positions, stops[:, c]) for c in range(3)], axis=2)
        pixels = np.ascontiguousarray(rgb[::-1].astype(np.uint8))
        h, w = pixels.shape[:2]
        self.image = QImage(pixels.data, w, h, pixels.strides[0], QImage.Format.Format_RGB888).copy()

    def time_at(self, x):
        r = self.area()
        fraction = np.clip((x - r.left()) / r.width(), 0, 1)
        return self.data['start'] + float(fraction) * (self.data['end'] - self.data['start'])

    def x_at(self, seconds):
        r = self.area()
        return r.left() + (seconds - self.data['start']) / (self.data['end'] - self.data['start']) * r.width()

    def paintEvent(self, event):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor('#0b1418'))
        r = self.area()
        p.setPen(QColor('#8aa297'))
        p.drawText(12, 19, '02 / SPECTROGRAM · Hz' if self.spectral else '01 / WAVEFORM · amplitude')
        if not self.data:
            p.setPen(QColor('#607970'))
            p.drawText(r, Qt.AlignmentFlag.AlignCenter, 'OPEN A WAV FILE TO BEGIN')
            return
        if self.spectral:
            p.drawImage(r, self.image)
        else:
            for index, (low, high) in enumerate(zip(self.data['low'], self.data['high'])):
                x = r.left() + (index + .5) / len(self.data['low']) * r.width()
                p.setPen(QPen(QColor('#92c7a3'), 1))
                p.drawLine(QPointF(x, r.center().y() - float(high) * r.height() * .46),
                           QPointF(x, r.center().y() - float(low) * r.height() * .46))
        p.setPen(QPen(QColor(122, 154, 139, 45), 1))
        for n in range(5):
            y = r.top() + n * r.height() / 4
            p.drawLine(QPointF(r.left(), y), QPointF(r.right(), y))
            value = self.source.rate / 2 * (1 - n / 4) if self.spectral else 1 - n / 2
            p.setPen(QColor('#8aa297'))
            p.drawText(QRectF(0, y - 8, 55, 18), Qt.AlignmentFlag.AlignRight,
                       f'{value / 1000:.1f}k' if self.spectral and value >= 1000 else f'{value:g}')
            p.setPen(QPen(QColor(122, 154, 139, 45), 1))
        for n in range(5):
            x = r.left() + n * r.width() / 4
            t = self.data['start'] + n / 4 * (self.data['end'] - self.data['start'])
            p.drawLine(QPointF(x, r.top()), QPointF(x, r.bottom()))
            p.setPen(QColor('#8aa297'))
            p.drawText(QRectF(x - 30, r.bottom() + 6, 60, 20), Qt.AlignmentFlag.AlignCenter, f'{t:.3f}s')
            p.setPen(QPen(QColor(122, 154, 139, 45), 1))
        a, b = self.selection
        if b > a:
            left, right = max(r.left(), self.x_at(a)), min(r.right(), self.x_at(b))
            if right > left:
                p.fillRect(QRectF(left, r.top(), right - left, r.height()), QColor(207, 191, 126, 40))
                p.setPen(QColor('#dccb91'))
                p.drawRect(QRectF(left, r.top(), right - left, r.height()))
        if self.playhead is not None and self.data['start'] <= self.playhead <= self.data['end']:
            p.setPen(QColor('#e8f3df'))
            x = self.x_at(self.playhead)
            p.drawLine(QPointF(x, r.top()), QPointF(x, r.bottom()))
        p.setPen(QColor('#425b51'))
        p.drawRect(r)

    def mousePressEvent(self, event):
        if self.data and event.button() == Qt.MouseButton.LeftButton and self.area().contains(event.position()):
            self.anchor = self.time_at(event.position().x())

    def mouseMoveEvent(self, event):
        if not self.data:
            return
        t = self.time_at(event.position().x())
        if self.anchor is not None:
            self.selection_changed.emit(min(self.anchor, t), max(self.anchor, t))
        if self.spectral:
            r = self.area()
            freq = float(np.clip((r.bottom() - event.position().y()) / r.height(), 0, 1)) * self.source.rate / 2
            col = min(self.data['spectrum'].shape[1] - 1, max(0, round((t - self.data['start']) /
                      (self.data['end'] - self.data['start']) * (self.data['spectrum'].shape[1] - 1))))
            row = min(self.data['spectrum'].shape[0] - 1, round(freq * self.data['nfft'] / self.source.rate))
            self.hovered.emit(f'{t:.3f} s  /  {freq:.1f} Hz  /  {self.data["spectrum"][row, col]:.1f} dBFS')
        else:
            self.hovered.emit(f'{t:.3f} s  /  drag to select')

    def mouseReleaseEvent(self, event):
        if self.anchor is not None:
            t = self.time_at(event.position().x())
            self.selection_changed.emit(min(self.anchor, t), max(self.anchor, t))
            self.anchor = None


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('SIGNAL SCOPE — WAV analysis')
        self.resize(1400, 930)
        self.setMinimumSize(1120, 760)
        self.source = None
        self.data = None
        self.worker = None
        self.pending = None
        self.closing = False
        self.view = (0., 1.)
        self.play_end = 0
        self.player = None
        self.audio_output = None
        self.playback_classes = None
        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)
        layout.setContentsMargins(24, 20, 24, 18)
        layout.setSpacing(14)
        header = QHBoxLayout()
        title = QVBoxLayout()
        title.addWidget(text('SIGNAL SCOPE', 'title'))
        title.addWidget(text('LOCAL AUDIO INSPECTION / v1.0.0', 'muted'))
        header.addLayout(title)
        header.addStretch()
        self.status = text('READY / NO SOURCE', 'accent')
        header.addWidget(self.status)
        self.open_button = button('OPEN WAV', self.choose_source)
        header.addWidget(self.open_button)
        layout.addLayout(header)
        tools = QHBoxLayout()
        self.channel = QComboBox()
        self.channel.addItem('Channel 1', 0)
        self.channel.currentIndexChanged.connect(self.refresh)
        tools.addWidget(text('CHANNEL', 'muted'))
        tools.addWidget(self.channel)
        self.fft = QComboBox()
        for n in (512, 1024, 2048, 4096):
            self.fft.addItem(str(n), n)
        self.fft.setCurrentIndex(2)
        self.fft.currentIndexChanged.connect(self.refresh)
        tools.addWidget(text('FFT', 'muted'))
        tools.addWidget(self.fft)
        self.dynamic = QComboBox()
        for n in (-60, -80, -100):
            self.dynamic.addItem(f'{n} .. 0 dBFS', n)
        self.dynamic.setCurrentIndex(1)
        self.dynamic.currentIndexChanged.connect(self.change_floor)
        tools.addWidget(self.dynamic)
        tools.addStretch()
        self.fit_button = button('FULL FILE', self.fit)
        self.zoom_button = button('ZOOM SELECTION', self.zoom_selection)
        tools.addWidget(self.fit_button)
        tools.addWidget(self.zoom_button)
        tools.addWidget(button('−', lambda: self.zoom(2)))
        tools.addWidget(button('+', lambda: self.zoom(.5)))
        layout.addLayout(tools)
        content = QHBoxLayout()
        plots = QVBoxLayout()
        split = QSplitter(Qt.Orientation.Vertical)
        self.waveform, self.spectrogram = Plot(), Plot(True)
        for plot in (self.waveform, self.spectrogram):
            plot.selection_changed.connect(self.set_selection)
            plot.hovered.connect(lambda msg: self.cursor.setText(msg))
            split.addWidget(plot)
        split.setSizes([260, 390])
        plots.addWidget(split, 1)
        self.scroll = QScrollBar(Qt.Orientation.Horizontal)
        self.scroll.setRange(0, 10000)
        self.scroll.sliderReleased.connect(self.pan)
        self.scroll.valueChanged.connect(lambda _: self.pan() if not self.scroll.isSliderDown() else None)
        plots.addWidget(self.scroll)
        self.cursor = text('TIME / FREQUENCY / AMPLITUDE', 'muted')
        plots.addWidget(self.cursor)
        content.addLayout(plots, 1)
        side = QFrame()
        side.setObjectName('panel')
        side.setFixedWidth(270)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(16, 16, 16, 16)
        sl.setSpacing(14)
        sl.addWidget(text('SOURCE / PCM WAV', 'accent'))
        self.filename = text('No file loaded')
        self.filename.setTextFormat(Qt.TextFormat.PlainText)
        self.filename.setWordWrap(True)
        sl.addWidget(self.filename)
        self.info = text('—', 'muted')
        sl.addWidget(self.info)
        sl.addWidget(text('VISIBLE RANGE / METRICS', 'accent'))
        self.metrics = text('—', 'muted')
        self.metrics.setWordWrap(True)
        sl.addWidget(self.metrics)
        sl.addWidget(text('SILENCE / ALL CHANNELS', 'accent'))
        sl.addWidget(text('≤ −50 dBFS · runs ≥ 0.25 s', 'muted'))
        self.silences = QListWidget()
        self.silences.itemClicked.connect(self.select_silence)
        sl.addWidget(self.silences, 1)
        hint = text('Click a silence interval to select it.\n\nSpectrogram: linear Hz; Hann window.\nColors show amplitude, not power/Hz.', 'muted')
        hint.setWordWrap(True)
        sl.addWidget(hint)
        content.addWidget(side)
        layout.addLayout(content, 1)
        selection = QHBoxLayout()
        selection.addWidget(text('SELECTION', 'accent'))
        self.start, self.end = QDoubleSpinBox(), QDoubleSpinBox()
        for box in (self.start, self.end):
            box.setDecimals(6)
            box.setRange(0, 0)
            box.setSuffix(' s')
            box.setKeyboardTracking(False)
            box.valueChanged.connect(self.selection_from_boxes)
        selection.addWidget(self.start)
        selection.addWidget(text('→'))
        selection.addWidget(self.end)
        self.duration_label = text('0.000 s', 'muted')
        selection.addWidget(self.duration_label)
        selection.addStretch()
        selection.addWidget(button('SELECT ALL', self.select_all))
        self.play_button = button('PLAY SELECTION', self.play)
        self.stop_button = button('STOP', self.stop)
        selection.addWidget(self.play_button)
        selection.addWidget(self.stop_button)
        self.export_button = button('EXPORT WAV', self.choose_export)
        self.export_button.setObjectName('primary')
        selection.addWidget(self.export_button)
        layout.addLayout(selection)
        self.footer = text('SOURCE PROTECTED / export preserves channels, sample rate and PCM bit depth', 'muted')
        layout.addWidget(self.footer)
        self.play_timer = QTimer(self)
        self.play_timer.timeout.connect(self.check_playback)
        self.play_timer.start(30)
        self.setup_playback()
        self.buttons()

    def setup_playback(self):
        try:
            from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
            # Defer audio-device initialization until playback is requested.
            self.playback_classes = QAudioOutput, QMediaPlayer
        except (ImportError, OSError):
            self.play_button.setToolTip('Qt multimedia is unavailable; analysis and export still work.')

    def buttons(self):
        loaded, idle = self.source is not None, self.worker is None
        for item in (self.open_button, self.channel, self.fft):
            item.setEnabled(idle)
        self.export_button.setEnabled(loaded and idle and self.end.value() > self.start.value())
        self.play_button.setEnabled(loaded and self.playback_classes is not None and self.end.value() > self.start.value())
        self.zoom_button.setEnabled(loaded and idle)
        self.fit_button.setEnabled(loaded and idle)
        self.scroll.setEnabled(loaded and idle)

    def task(self, operation, callback, status):
        if self.worker is not None:
            return
        self.status.setText(status)
        self.worker = Task(operation, self)
        self.worker.result.connect(callback)
        self.worker.error.connect(self.error)
        self.worker.finished.connect(self.finished)
        self.buttons()
        self.worker.start()

    def error(self, message):
        self.status.setText('OPERATION FAILED')
        if not self.closing:
            QMessageBox.warning(self, 'Operation failed', message)

    def finished(self):
        old = self.worker
        self.worker = None
        old.deleteLater()
        if self.closing:
            self.close()
            return
        self.buttons()
        if self.pending is not None:
            view = self.pending
            self.pending = None
            self.request_view(*view)

    def choose_source(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Open PCM WAV', '', 'WAV audio (*.wav)')
        if path:
            self.load_path(path)

    def load_path(self, path):
        if self.worker is not None:
            return
        self.stop()
        def load():
            source = open_source(path)
            return source, analyze(source, 0, source.duration)
        self.task(load, self.loaded, 'READING / ANALYZING WAV…')

    def loaded(self, result):
        self.source, data = result
        self.channel.blockSignals(True)
        self.channel.clear()
        for i in range(self.source.channels):
            self.channel.addItem(f'Channel {i + 1}', i)
        if self.source.channels > 1:
            self.channel.addItem('Mix (average)', -1)
        self.channel.blockSignals(False)
        self.fft.blockSignals(True)
        self.fft.setCurrentIndex(2)
        self.fft.blockSignals(False)
        self.filename.setText(self.source.path.name)
        s = self.source
        self.info.setText(f'{s.duration:.3f} seconds\n{s.rate:,} Hz\n{s.channels} channel(s)\n{s.width * 8}-bit integer PCM\n{s.frames:,} frames')
        for box in (self.start, self.end):
            box.blockSignals(True)
            box.setMaximum(s.duration)
            box.setSingleStep(1 / s.rate)
            box.blockSignals(False)
        self.view = (0., s.duration)
        self.set_selection(0, s.duration)
        self.show_analysis(data)
        if self.player:
            self.player.setSource(QUrl.fromLocalFile(str(s.path)))

    def refresh(self, *_):
        if self.source:
            self.request_view(*self.view)

    def request_view(self, start, end):
        if not self.source:
            return
        width = min(self.source.duration, max(1 / self.source.rate, end - start))
        start = max(0, min(start, self.source.duration - width))
        end = min(self.source.duration, start + width)
        if self.worker is not None:
            self.pending = (start, end)
            return
        self.view = start, end
        source, channel, nfft = self.source, self.channel.currentData(), self.fft.currentData()
        self.task(lambda: analyze(source, start, end, channel, nfft), self.show_analysis, 'ANALYZING VIEW…')

    def show_analysis(self, data):
        self.data = data
        self.view = data['start'], data['end']
        for plot in (self.waveform, self.spectrogram):
            plot.set_data(self.source, data)
        self.metrics.setText(f'Peak   {data["peak"]:.1f} dBFS\nRMS    {data["rms"]:.1f} dBFS\nAt rail: {data["clipped"]:,} samples\nFFT bin: {self.source.rate / data["nfft"]:.2f} Hz')
        self.silences.clear()
        for a, b in data['silence']:
            self.silences.addItem(f'{a:.3f} → {b:.3f} s')
        self.scroll.blockSignals(True)
        span = self.source.duration - (self.view[1] - self.view[0])
        self.scroll.setValue(round(self.view[0] / span * 10000) if span > 0 else 0)
        self.scroll.setPageStep(max(1, round((self.view[1] - self.view[0]) / self.source.duration * 10000)))
        self.scroll.blockSignals(False)
        mode = 'TIME-SAMPLED STFT / zoom in for short events' if data['sampled'] else 'STFT READY'
        self.status.setText(mode)

    def change_floor(self, *_):
        self.spectrogram.floor = self.dynamic.currentData()
        self.spectrogram.colorize()
        self.spectrogram.update()

    def set_selection(self, start, end):
        if not self.source:
            return
        a = round(max(0, min(start, self.source.duration)) * self.source.rate) / self.source.rate
        b = round(max(0, min(end, self.source.duration)) * self.source.rate) / self.source.rate
        a, b = min(a, b), max(a, b)
        for box, value in ((self.start, a), (self.end, b)):
            box.blockSignals(True)
            box.setValue(value)
            box.blockSignals(False)
        for plot in (self.waveform, self.spectrogram):
            plot.selection = (a, b)
            plot.update()
        self.duration_label.setText(f'{b - a:.6f} s')
        self.buttons()

    def selection_from_boxes(self, *_):
        if self.player:
            self.stop()
        self.set_selection(self.start.value(), self.end.value())

    def select_silence(self, item):
        index = self.silences.row(item)
        self.set_selection(*self.data['silence'][index])

    def select_all(self):
        if self.source:
            self.set_selection(0, self.source.duration)

    def fit(self):
        if self.source:
            self.request_view(0, self.source.duration)

    def zoom_selection(self):
        if self.end.value() > self.start.value():
            self.request_view(self.start.value(), self.end.value())

    def zoom(self, factor):
        center = sum(self.view) / 2
        half = (self.view[1] - self.view[0]) * factor / 2
        self.request_view(center - half, center + half)

    def pan(self):
        if self.source:
            width = self.view[1] - self.view[0]
            start = (self.source.duration - width) * self.scroll.value() / 10000
            self.request_view(start, start + width)

    def play(self):
        if not self.playback_classes or not self.source:
            return
        if self.player is None:
            QAudioOutput, QMediaPlayer = self.playback_classes
            self.audio_output = QAudioOutput(self)
            self.audio_output.setVolume(.65)
            self.player = QMediaPlayer(self)
            self.player.setAudioOutput(self.audio_output)
            self.player.errorOccurred.connect(lambda *_: self.playback_error())
            self.player.setSource(QUrl.fromLocalFile(str(self.source.path)))
        self.play_end = self.end.value()
        self.player.setPosition(round(self.start.value() * 1000))
        self.player.play()

    def stop(self):
        if self.player:
            self.player.pause()
        for plot in (self.waveform, self.spectrogram):
            plot.playhead = None
            plot.update()

    def check_playback(self):
        if not self.player or not self.source:
            return
        from PySide6.QtMultimedia import QMediaPlayer
        if self.player.playbackState() == QMediaPlayer.PlaybackState.PlayingState:
            seconds = self.player.position() / 1000
            if seconds >= self.play_end:
                self.stop()
                return
            for plot in (self.waveform, self.spectrogram):
                plot.playhead = seconds
                plot.update()

    def playback_error(self):
        self.footer.setText('PLAYBACK UNAVAILABLE / ' + self.player.errorString())
        self.stop()

    def choose_export(self):
        if not self.source or self.worker is not None:
            return
        default = str(self.source.path.with_name(self.source.path.stem + '_selection.wav'))
        path, _ = QFileDialog.getSaveFileName(self, 'Export selected frames', default, 'WAV audio (*.wav)')
        if not path:
            return
        if not Path(path).suffix:
            path += '.wav'
        if Path(path).exists():
            answer = QMessageBox.question(self, 'Replace export?', 'Replace the existing destination file?')
            if answer != QMessageBox.StandardButton.Yes:
                return
        source, start, end = self.source, self.start.value(), self.end.value()
        self.task(lambda: export_selection(source, path, start, end),
                  lambda _: self.status.setText('EXPORTED / ' + Path(path).name), 'EXPORTING…')

    def closeEvent(self, event):
        self.stop()
        if self.worker is not None:
            self.closing = True
            self.pending = None
            self.centralWidget().setEnabled(False)
            self.status.setText('FINISHING OPERATION…')
            event.ignore()
        else:
            event.accept()


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setStyleSheet(STYLE)
    app.setFont(QFont('Consolas', 10))
    window = Window()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
