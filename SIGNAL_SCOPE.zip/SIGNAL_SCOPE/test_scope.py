import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import tempfile
import time
import unittest
import wave
from pathlib import Path
from unittest.mock import patch

import numpy as np
from audio import analyze, decode, export_selection, frame_range, open_source


def write_wav(path, raw, rate=8000, channels=1, width=2):
    with wave.open(str(path), 'wb') as writer:
        writer.setnchannels(channels)
        writer.setsampwidth(width)
        writer.setframerate(rate)
        writer.writeframes(raw)


def encode(samples, width):
    if width == 1:
        return samples.astype('u1').tobytes()
    if width == 3:
        v = samples.astype(np.int32).reshape(-1)
        return np.stack([v & 255, (v >> 8) & 255, (v >> 16) & 255], axis=1).astype('u1').tobytes()
    return samples.astype(f'<i{width}').tobytes()


class AudioTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.folder = Path(self.temp.name)
        t = np.arange(16000) / 8000
        self.raw = (np.sin(2 * np.pi * 1000 * t) * 16384).astype('<i2').tobytes()
        self.path = self.folder / 'tone.wav'
        write_wav(self.path, self.raw)
        self.source = open_source(self.path)

    def test_pcm_depths_and_exact_export(self):
        for width in (1, 2, 3, 4):
            low, high = (0, 255) if width == 1 else (-(2 ** (width * 8 - 1)), 2 ** (width * 8 - 1) - 1)
            values = np.array([low, high, 128 if width == 1 else 0] * 100, dtype=np.int64)
            raw = encode(values, width)
            source_path = self.folder / f'source-{width}.wav'
            write_wav(source_path, raw, channels=2, width=width)
            source = open_source(source_path)
            result = analyze(source, 0, source.duration, nfft=512)
            self.assertEqual(result['clipped'], 200)
            decoded = decode(raw, width, 2)
            self.assertEqual(decoded.shape, (150, 2))
            self.assertAlmostEqual(decoded.reshape(-1)[0], -1)
            output = self.folder / f'out-{width}.wav'
            export_selection(source, output, 10 / 8000, 90 / 8000)
            with wave.open(str(output)) as reader:
                self.assertEqual(reader.getnframes(), 80)
                self.assertEqual(reader.getsampwidth(), width)
                self.assertEqual(reader.getnchannels(), 2)
                self.assertEqual(reader.readframes(80), raw[10 * width * 2:90 * width * 2])
            self.assertEqual(source_path.read_bytes()[44:], raw)

    def test_fft_frequency_and_level(self):
        result = analyze(self.source, 0, 2, nfft=1024)
        spectrum = result['spectrum'][:, result['spectrum'].shape[1] // 2]
        self.assertEqual(int(np.argmax(spectrum)), 128)
        self.assertAlmostEqual(float(spectrum[128]), -6.02, delta=.1)
        self.assertAlmostEqual(result['peak'], -6.02, delta=.1)
        self.assertAlmostEqual(result['rms'], -9.03, delta=.1)
        self.assertEqual(result['silence'], [])
        self.assertLessEqual(result['spectrum'].shape[1], 1200)

    def test_silence_does_not_cancel_stereo(self):
        mono = np.frombuffer(self.raw, '<i2')
        stereo = np.stack([mono, -mono], axis=1)
        stereo[4000:8000] = 0
        path = self.folder / 'stereo.wav'
        write_wav(path, stereo.astype('<i2').tobytes(), channels=2)
        result = analyze(open_source(path), 0, 2, channel=-1, nfft=512)
        self.assertEqual(result['silence'], [(.5, 1.)])
        self.assertAlmostEqual(result['peak'], -240)

    def test_empty_invalid_and_source_protection(self):
        for name, raw in [('bad.wav', b'broken'), ('empty.wav', b'')]:
            p = self.folder / name
            p.write_bytes(raw)
            with self.assertRaises((ValueError, EOFError)):
                open_source(p)
        empty = self.folder / 'zero.wav'
        write_wav(empty, b'')
        with self.assertRaises(ValueError):
            open_source(empty)
        truncated = self.folder / 'truncated.wav'
        truncated.write_bytes(self.path.read_bytes()[:-3])
        with self.assertRaises(ValueError):
            open_source(truncated)
        with self.assertRaises(ValueError):
            export_selection(self.source, self.path, 0, 1)
        link = self.folder / 'alias.wav'
        os.link(self.path, link)
        with self.assertRaises(ValueError):
            export_selection(self.source, link, 0, 1)
        for a, b in [(1, 1), (2, 1), (float('nan'), 1)]:
            with self.assertRaises(ValueError):
                frame_range(self.source, a, b)
        with self.assertRaises(ValueError):
            analyze(self.source, 0, 1, channel=2)

    def test_short_and_rail_neighbours(self):
        path = self.folder / 'short.wav'
        raw = np.array([2147483646, -2147483647], dtype='<i4').tobytes()
        write_wav(path, raw, width=4)
        source = open_source(path)
        result = analyze(source, 0, source.duration)
        self.assertEqual(result['clipped'], 0)
        self.assertTrue(np.isfinite(result['spectrum']).all())
        self.assertTrue(np.isfinite(result['low']).all())
        self.assertEqual(result['spectrum'].shape[1], 1)

    def test_gui_workflow(self):
        from PySide6.QtWidgets import QApplication
        from PySide6.QtCore import Qt, QPoint
        from PySide6.QtTest import QTest
        from main import Window, STYLE
        app = QApplication.instance() or QApplication([])
        app.setStyleSheet(STYLE)
        w = Window()
        w.show()

        def wait():
            deadline = time.monotonic() + 30
            while w.worker is not None or w.pending is not None:
                app.processEvents()
                if time.monotonic() > deadline:
                    self.fail('Background task timed out')
                time.sleep(.01)
            app.processEvents()

        try:
            w.load_path(self.path)
            wait()
            self.assertTrue(w.isVisible())
            self.assertEqual(w.source.frames, 16000)
            rect = w.waveform.area()
            a = QPoint(round(rect.left() + rect.width() * .25), round(rect.center().y()))
            b = QPoint(round(rect.left() + rect.width() * .75), round(rect.center().y()))
            QTest.mousePress(w.waveform, Qt.MouseButton.LeftButton, pos=a)
            QTest.mouseMove(w.waveform, b)
            QTest.mouseRelease(w.waveform, Qt.MouseButton.LeftButton, pos=b)
            self.assertAlmostEqual(w.start.value(), .5, delta=.01)
            self.assertAlmostEqual(w.end.value(), 1.5, delta=.01)
            w.zoom_selection()
            wait()
            self.assertAlmostEqual(w.view[1] - w.view[0], 1, delta=.02)
            w.fft.setCurrentIndex(3)
            wait()
            self.assertEqual(w.data['nfft'], 4096)
            w.dynamic.setCurrentIndex(2)
            w.fit()
            wait()
            w.set_selection(.25, .75)
            target = self.folder / 'gui.wav'
            with patch('main.QFileDialog.getSaveFileName', return_value=(str(target), 'WAV audio (*.wav)')):
                w.choose_export()
                wait()
            self.assertEqual(open_source(target).frames, 4000)
            with patch('main.QMessageBox.warning') as warning:
                w.load_path(self.folder / 'missing.wav')
                wait()
                warning.assert_called_once()
            self.assertEqual(w.source.path, self.path)
            # Keep a visual check outside the deliverable archive.
            if os.environ.get('SCOPE_SCREENSHOT'):
                w.grab().save(os.environ['SCOPE_SCREENSHOT'])
        finally:
            wait()
            w.close()
            app.processEvents()


if __name__ == '__main__':
    unittest.main()
